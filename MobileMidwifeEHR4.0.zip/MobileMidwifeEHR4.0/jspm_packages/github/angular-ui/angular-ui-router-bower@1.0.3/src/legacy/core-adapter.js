var core = require('@uirouter/angularjs').core;
module.exports = core;
