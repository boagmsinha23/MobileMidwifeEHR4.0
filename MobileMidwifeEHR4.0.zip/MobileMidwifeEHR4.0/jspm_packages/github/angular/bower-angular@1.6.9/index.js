/* */ 
"format cjs";
require('./angular');
module.exports = angular;
