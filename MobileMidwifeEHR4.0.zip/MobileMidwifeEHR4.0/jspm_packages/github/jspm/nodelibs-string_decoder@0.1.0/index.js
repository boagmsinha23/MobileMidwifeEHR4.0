/* */ 
module.exports = System._nodeRequire ? System._nodeRequire('string_decoder') : require('string_decoder');